/**
  \file      TD20210419.c
  \brief     Memory allocation
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-03-29 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "wav.h"


#define MAX_LINE_LENGHT 100

int getWaveInfo(char* filename, uint32_t *fs, uint32_t *numSamples) {
  int returnCode = 0;
  const char *mode = "rb";
  FILE *fIn = NULL;
  sWavHeader h;

  fIn = fopen(filename, mode);
  if(fIn!=NULL) {
    if(1==fread(&h,sizeof(sWavHeader),1, fIn)) {
      *fs = h.format.samplingRate;
      *numSamples = h.data.length / h.format.bytesPerSample;
    }
    else {
      printf("Error while reading header of %s\n", filename);
      returnCode = -1;
    }
    if(0!=fclose(fIn)) {
      printf("Error while clsing %s\n", filename);
      returnCode = -1;
    }
  }
  else {
    printf("Error while opening %s\n", filename);
    returnCode = -1;
  }
  return returnCode;
}

int main(int argc, char const *argv[])
{
  const char *filename = "melody.txt";
  const char *mode = "r";
  FILE *fIn = NULL;
  char s[MAX_LINE_LENGHT];
  uint32_t fs = 0;
  uint32_t numSamples = 0;

  fIn = fopen(filename, mode);
  if(fIn!=NULL) {

    while(!feof(fIn)) {
      fgets(s, MAX_LINE_LENGHT, fIn); // read one line
      if(strchr(s,'\n')) {  // suppress \n if any
        s[strlen(s) - 1] = '\0';
      }
      getWaveInfo(s, &fs, &numSamples);
      printf("wav filename: %s    %6u   %6u\n", s, fs, numSamples);

    }

    if(0!=fclose(fIn)) {
      printf("Error while closing %s\n", filename);
    }
  }
  else {
    printf("Error while opening %s\n", filename);
  }

  return 0;
}



