/**
  \file      TD20210510.c
  \brief     chained list test
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "chained_list.h"
#include "error.h"

int main(int argc, char const *argv[])
{
  sElem *elem;
  chainedList l = {NULL, NULL, 0};

  // insert elements at first position
  elem = createElem(3.);
  printf("%lf\n", elem->e);
  insertElemAt(&l, 0, elem);

  elem = createElem(2.);
  insertElemAt(&l, 0, elem);

  elem = createElem(1.);
  insertElemAt(&l, 0, elem);

  displayList(&l);

  // insert elements at last position
  elem = createElem(4.);
  insertElemAt(&l, END_OF_LIST, elem);

  elem = createElem(5.);
  insertElemAt(&l, END_OF_LIST, elem);

  elem = createElem(6.);
  insertElemAt(&l, 5, elem);

  displayList(&l);

  // insert elements at specific position
  elem = createElem(42.);
  insertElemAt(&l, 1, elem);

  displayList(&l);


  displayReverse(&l);

  freeList(&l);
  return 0;
}















