// chained_list.c

#include "chained_list.h"


sElem *createElem(Element data) {

  sElem *p = (sElem *)malloc(sizeof(sElem));
  if(NULL!=p) {
    p->e = data;
    p->next = NULL;
    p->prev = NULL;
  }
  return p;
}

bool insertElemAtNotOptimized(chainedList *list, int32_t pos, sElem *x) {

  sElem *p = NULL;
  sElem *n = NULL;
  int32_t k = 0;

  if(list==NULL || x==NULL) {
    return false;
  }

  if (pos == 0)
  {                        // insert at first position
    if(list->numElem==0) { // list is empty
      x->next = NULL;
      x->prev = NULL;
      list->first = x;
      list->last = x;
    }
    else {
      list->first->prev = x;
      x->next = list->first;
      x->prev = NULL;
      list->first = x;
    }
    list->numElem++;
  }
  else   if(pos==END_OF_LIST || pos==list->numElem) { // insert at last position
    if(list->numElem==0) { // list is empty
      x->next = NULL;
      x->prev = NULL;
      list->first = x;
      list->last = x;
    }
    else {
      x->next = NULL;
      x->prev = list->last;
      list->last->next = x;
      list->last = x;
    }
    list->numElem++;
  }
  else {
    n = list->first;
    for (k = 0; k < pos;k++) {
      n = n->next;
      p = n->prev;
    }
    x->next = n;
    x->prev = p;
    n->prev = x;
    p->next = x;
    list->numElem++;
   }

  return true;
}


bool insertElemAt(chainedList *list, int32_t pos, sElem *x) {

  sElem *n = NULL;

  if(list==NULL || x==NULL) {
    return false;
  }
  x->prev = NULL;
  x->next = NULL;

  if (pos == 0)
  {                        // insert at first position
    if(list->numElem==0) { // list is empty
      list->last = x;
    }
    else {
      list->first->prev = x;
      x->next = list->first;
    }
    list->first = x;
  }

  else   if(pos==END_OF_LIST || pos==list->numElem) { // insert at last position
    if(list->numElem==0) { // list is empty
      list->first = x;
    }
    else {
      x->prev = list->last;
      list->last->next = x;
    }
    list->last = x;
  }

  else { // insert between first / last position
    n = list->first;
    while(pos--) {
      n = n->next;
    }
    x->next = n;
    x->prev = n->prev;
    n->prev->next = x;
    n->prev = x;
  }
  list->numElem++;

  return true;
}

void displayList(chainedList *l) {
  sElem *e = l->first;
  printf("N=%d\n", l->numElem);
  while(e) {
    printf("%p  %lf\n", e,e->e);
    e = e->next;
  }
  return;
}

void displayReverse(chainedList *l) {
  sElem *e = l->last;
  printf("N=%d\n", l->numElem);
  while(e) {
    printf("%lf\n", e->e);
    e = e->prev;
  }
  return;
}


void freeElem(sElem *elem) {
  if(elem)
    free(elem);
  return;
}

void freeList(chainedList *l) {
  sElem *e = l->first;
  sElem *n = NULL;
  while(e) {
    n = e->next;
    freeElem(e);
    e = n;
  }
  return;
}