// chained_list.h

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#define END_OF_LIST (-1)

typedef double Element; // element in list (payload)

typedef struct sElem
{
    struct sElem *next;
    struct sElem *prev;
    Element e;
} sElem;

typedef struct
{
    sElem *first;
    sElem *last;
    uint32_t numElem;
} chainedList;

sElem *createElem(Element data);
bool insertElemAt(chainedList *list, int32_t pos, sElem *x);
void freeElem(sElem *elem);
void displayList(chainedList *l);
void displayReverse(chainedList *l);
