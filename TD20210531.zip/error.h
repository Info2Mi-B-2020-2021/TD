// error.h

#pragma once

#include <stdio.h>

typedef enum
{
    E_NO_ERROR = 0,
    E_BAD_LIST,
    E_LIST_FULL,
} eErrorCode;

void displayError(const eErrorCode e);
