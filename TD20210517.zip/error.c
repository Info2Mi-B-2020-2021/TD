// error.c

#include "error.h"


void displayError(const eErrorCode e) {

  switch(e) {
    case E_NO_ERROR:
      printf("NO ERROR\n");
      break;
    case E_ERROR_1:
      printf("E_ERROR_1\n");
      break;
    case E_ERROR_2:
      printf("E_ERROR_2\n");
      break;
    default:
      printf("UNKNOWN ERROR\n");
      break;
  }
  return;
}
