// error.h

#pragma once

#include <stdio.h> // standard library for inputs and ouputs

typedef enum
{
    E_NO_ERROR = 0,
    E_ERROR_1,
    E_ERROR_2,
    E_ERROR_3
} eErrorCode;

void displayError(const eErrorCode e);
