/**
 * \brief	Project INFO2
 * \file	bitmap.h
 * \author	Pierre BRESSY
 * \version	1.0
 * \date	29.12.11, 15:14
 * \bug		None.
 * \details	header file for bitmap image handling.
 */

#pragma once

// Bitmap magic number 'B' 'M'
#define BITMAP_TYPE 19778

#pragma pack(1)

typedef struct
{
    uint8_t B, G, R;
} sRGB;

typedef struct
{
    uint16_t bfType;      // BITMAP_TYPE
    uint32_t bfSize;      // total file size
    uint16_t bfReserved1; // 0
    uint16_t bfReserved2; // 0
    uint32_t bfOffBits;   // sizeof(sBitmapFileHeader) + sizeof(sBitMapInfoHeader)
} sBitmapFileHeader;

typedef struct
{
    uint32_t biSize;         // sizeof(sBitMapInfoHeader)
    int32_t biWidth;         // image width in pixels
    int32_t biHeight;        // image height in pixels
    uint16_t biPlanes;       // 1
    uint16_t biBitCount;     // 24
    uint32_t biCompression;  // 0
    uint32_t biSizeImage;    // 0
    int32_t biXPelsPerMeter; // 2835
    int32_t biYPelsPerMeter; // 2835
    uint32_t biClrUsed;      // 0
    uint32_t biClrImportant; // 0
} sBitMapInfoHeader;

#pragma pack(0)
