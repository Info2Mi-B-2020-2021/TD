/**
 * \brief	Project INFO2
 * \file	wav.c
 * \author	Pierre BRESSY
 * \version	1.0
 * \date	29.12.11, 15:14
 * \bug		None.
 * \details	wav file library source file.
 */


#include "wav.h"

void prepareRiffHeader(sRiffHeader * _riff, const uint32_t _dataLength) {

	assert(_riff != NULL);

	_riff->riff[0] = 'R';
	_riff->riff[1] = 'I';
	_riff->riff[2] = 'F';
	_riff->riff[3] = 'F';
	_riff->length = (uint32_t)(_dataLength + sizeof(sWavHeader) - 8);
	_riff->wav[0] = 'W';
	_riff->wav[1] = 'A';
	_riff->wav[2] = 'V';
	_riff->wav[3] = 'E';
	
	return;
}

void prepareFormatHeader(sFormatHeader * _format, const eWavChannels _numChannels, const uint32_t _samplingRate, const uint32_t _bitPerSample) {

	assert(_format != NULL);
	assert(_numChannels == 1 || _numChannels==2);
	assert(_bitPerSample == E_8B_SAMPLE || _bitPerSample==E_16B_SAMPLE);

	_format->fmt[0] = 'f';
	_format->fmt[1] = 'm';
	_format->fmt[2] = 't';
	_format->fmt[3] = ' ';
	_format->length = 0x10;
	_format->audioFormat = 1; // PCM
	_format->numChannels = _numChannels;
	_format->samplingRate = _samplingRate;
	_format->byteRate = _samplingRate * _numChannels * _bitPerSample / 8;
	_format->bytesPerSample = _numChannels * _bitPerSample / 8;
	_format->bitPerSample = _bitPerSample;
	
	return;
}

void prepareDataHeader(sDataHeader * _data, const uint32_t _dataLength) {

	assert(_data != NULL);

	_data->data[0] = 'd';
	_data->data[1] = 'a';
	_data->data[2] = 't';
	_data->data[3] = 'a';
	_data->length = (uint32_t)_dataLength;
	
	return;
}

void wavPrepareHeader(sWavHeader * _header, const eWavChannels _numChannels, const uint32_t _samplingRate, const uint32_t _numSamples, const eWavSampleSize _bitPerSample) {
	
	uint32_t dataLength = _numChannels * _numSamples * _bitPerSample / 8;
	
	assert(_header != NULL);
	assert(_numChannels == 1 || _numChannels==2);
	assert(_bitPerSample == E_8B_SAMPLE || _bitPerSample==E_16B_SAMPLE);

	prepareRiffHeader(&_header->riff, dataLength);
	prepareFormatHeader(&_header->format, _numChannels, _samplingRate, _bitPerSample);
	prepareDataHeader(&_header->data, dataLength);

	return;
}
