/**
  \file      TD20210419.c
  \brief     Memory allocation
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-03-29 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "wav.h"


#define MAX_LINE_LENGHT 100

typedef struct {
  int16_t left;
  int16_t right;

} sStereoSample;


int getWaveData(char* filename, sStereoSample *area) {
  int returnCode = 0;
  const char *mode = "rb";
  FILE *fIn = NULL;
  sWavHeader h;
  uint32_t numSamples = 0;

  fIn = fopen(filename, mode);
  if(fIn!=NULL) {
    if(1==fread(&h,sizeof(sWavHeader),1, fIn)) {
      numSamples = h.data.length / h.format.bytesPerSample;
      if(numSamples!=fread(area, sizeof(sStereoSample), numSamples, fIn)) {
        printf("Error while reading data of %s\n", filename);
        returnCode = -1;
      }
    }
    else {
      printf("Error while reading header of %s\n", filename);
      returnCode = -1;
    }
    if(0!=fclose(fIn)) {
      printf("Error while clsing %s\n", filename);
      returnCode = -1;
    }
  }
  else {
    printf("Error while opening %s\n", filename);
    returnCode = -1;
  }
  return returnCode;
 
}

int getWaveInfo(char* filename, uint32_t *fs, uint32_t *numSamples) {
  int returnCode = 0;
  const char *mode = "rb";
  FILE *fIn = NULL;
  sWavHeader h;

  fIn = fopen(filename, mode);
  if(fIn!=NULL) {
    if(1==fread(&h,sizeof(sWavHeader),1, fIn)) {
      *fs = h.format.samplingRate;
      *numSamples = h.data.length / h.format.bytesPerSample;
    }
    else {
      printf("Error while reading header of %s\n", filename);
      returnCode = -1;
    }
    if(0!=fclose(fIn)) {
      printf("Error while clsing %s\n", filename);
      returnCode = -1;
    }
  }
  else {
    printf("Error while opening %s\n", filename);
    returnCode = -1;
  }
  return returnCode;
}

int writeOutput(sStereoSample *area, const double fs, const uint32_t numSamples) {
  int returnCode = 0;
  const char *filename = "output.wav";
  const char *mode = "wb";
  FILE *fOut = NULL;
  sWavHeader h;

  wavPrepareHeader(&h, E_STEREO, fs, numSamples, E_16B_SAMPLE);
  fOut = fopen(filename, mode);
  if(fOut!=NULL) {
    if(1!=fwrite(&h, sizeof(sWavHeader), 1, fOut)) {
      printf("Error while writing header to %s\n", filename);
      returnCode = -1;
    }
    if(numSamples!=fwrite(area, sizeof(sStereoSample), numSamples, fOut)) {
      printf("Error while writing data to %s\n", filename);
      returnCode = -1;
    }
    if(0!=fclose(fOut)) {
      printf("Error while closing %s\n", filename);
      returnCode = -1;
    }
  }
  return returnCode;

}


int main(int argc, char const *argv[])
{
  const char *filename = "melody.txt";
  const char *mode = "r";
  FILE *fIn = NULL;
  char s[MAX_LINE_LENGHT];
  uint32_t fs = 0;
  uint32_t numSamples = 0;
  uint32_t totalNumSamples = 0;
  sStereoSample *t = NULL;
  sStereoSample *newT = NULL;
  
  fIn = fopen(filename, mode);
  if(fIn!=NULL) {

    while(!feof(fIn)) {
      fgets(s, MAX_LINE_LENGHT, fIn); // read one line
      if(strchr(s,'\n')) {  // suppress \n if any
        s[strlen(s) - 1] = '\0';
      }
      if(0!=getWaveInfo(s, &fs, &numSamples)) {
        printf("Error while reading header of %s\n", s);
      }
      printf("wav filename: %s    %6u   %6u\n", s, fs, numSamples);

      totalNumSamples += numSamples;
      printf("Allocation %u samples...\n", totalNumSamples);
      newT = (sStereoSample *)realloc(t, totalNumSamples * sizeof(sStereoSample));
      if(newT!=NULL) {
        t = newT;

        if(0!=getWaveData(s, t + totalNumSamples - numSamples)) {
          printf("Error while reading data of %s\n", s);
        }
      }
      else {
        printf("Error while allocating %lu bytes\n", totalNumSamples * sizeof(sStereoSample));
      }
    }

    if(t!=NULL) {
      if(0!=writeOutput(t, fs, totalNumSamples)) {
        printf("Error while writing output wav file\n");
      }
      free(t);
      t = NULL;
    }

    if(0!=fclose(fIn)) {
      printf("Error while closing %s\n", filename);
    }
  }
  else {
    printf("Error while opening %s\n", filename);
  }

  return 0;
}



