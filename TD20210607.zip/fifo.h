// fifo.h

#pragma once

#include "list.h"
#include "error.h"

eErrorCode put(pList l, Element e);
Element get(pList l);
 