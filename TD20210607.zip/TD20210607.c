/**
  \file      TD20210510.c
  \brief     bitmap file
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-05-10 13:15:00
  \details

**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <stdint.h>

#include "lifo.h"
#include "fifo.h"
#include "error.h"

int main(int argc, char const *argv[])
{
#if 0
  sList l;
  Element e;

  initList(&l);
  put(&l, 1.0);
  put(&l, 2.0);
  put(&l, 3.0);
  displayList(&l);
  e = get(&l);
  printf("e=%lf\n", e);
  displayList(&l);
  e = get(&l);
  printf("e=%lf\n", e);
  displayList(&l);
  e = get(&l);
  printf("e=%lf\n", e);
  freeList(&l);

#endif
#if 1
  sList l;
  Element e;

  initList(&l);
  push(&l, 1.0);
  push(&l, 2.0);
  push(&l, 3.0);
  displayList(&l);
  e = pop(&l);
  printf("e=%lf\n", e);
  displayList(&l);
  e = pop(&l);
  printf("e=%lf\n", e);
  displayList(&l);
  e = pop(&l);
  printf("e=%lf\n", e);
  freeList(&l);
#endif
  return 0;
}















