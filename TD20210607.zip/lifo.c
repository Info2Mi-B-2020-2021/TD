// lifo.c

#include "lifo.h"


eErrorCode push(pList l, Element e) {

  eErrorCode returnCode = E_NO_ERROR;

  if(l!=NULL) {
      insertElemAt(l, END_OF_LIST, e);
  }
  else {
    returnCode = E_BAD_LIST;
  }
  return returnCode;
}

Element pop(pList l) {
    Element e;
    if (l != NULL)
    {
        e = l->e[l->numElem - 1];
        deleteElemAt(l, END_OF_LIST);
    }
  else {
      printf("Error bad list.\n");
  }
  return e;
}
