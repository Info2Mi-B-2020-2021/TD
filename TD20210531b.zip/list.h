// list.h

#pragma once

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "error.h"

#define LIST_CAPACITY 10 // list size
#define LIST_RESIZE 10   // list resize
#define END_OF_LIST (-1)

typedef double Element; // element in list

typedef struct
{
  uint32_t numElem;
  uint32_t maxNumElem;
  Element *e;
} sList, *pList;

void displayList(sList l);
eErrorCode initList(pList l);
eErrorCode freeList(pList l);
bool isListEmpty(sList l);
bool isListFull(sList l);
int32_t getNumElem(sList l);
eErrorCode insertElemAt(pList l, int32_t pos, Element e);
int32_t searchElemByValue(pList l, Element e);
eErrorCode deleteElemAt(pList l, int32_t pos);
